<?php
/**
 * Bilingual (TH default / EN) seeding via Polylang + live articles import.
 */

function gg_seed_polylang_languages() {
	if ( ! function_exists( 'PLL' ) || ! PLL() || empty( PLL()->model ) ) {
		return false;
	}
	$model = PLL()->model;
	$langs = array(
		array(
			'name'       => 'ไทย',
			'slug'       => 'th',
			'locale'     => 'th',
			'rtl'        => 0,
			'flag'       => 'th',
			'term_group' => 0,
		),
		array(
			'name'       => 'English',
			'slug'       => 'en',
			'locale'     => 'en_US',
			'rtl'        => 0,
			'flag'       => 'us',
			'term_group' => 1,
		),
	);
	foreach ( $langs as $args ) {
		$existing = $model->get_language( $args['slug'] );
		if ( ! $existing ) {
			$model->add_language( $args );
		}
	}
	if ( method_exists( $model, 'update_default_lang' ) ) {
		$model->update_default_lang( 'th' );
	} elseif ( method_exists( $model, 'languages' ) && method_exists( $model->languages, 'update_default' ) ) {
		$model->languages->update_default( 'th' );
	} else {
		$opt = get_option( 'polylang' );
		if ( ! is_array( $opt ) ) {
			$opt = array();
		}
		$opt['default_lang'] = 'th';
		update_option( 'polylang', $opt );
	}
	// Hide URL language for default (TH) when possible.
	$opt = get_option( 'polylang' );
	if ( ! is_array( $opt ) ) {
		$opt = array();
	}
	$opt['default_lang'] = 'th';
	$opt['force_lang']   = isset( $opt['force_lang'] ) ? $opt['force_lang'] : 1;
	$opt['hide_default'] = 1;
	update_option( 'polylang', $opt );
	return true;
}

function gg_seed_set_lang( $post_id, $lang ) {
	if ( function_exists( 'pll_set_post_language' ) ) {
		pll_set_post_language( $post_id, $lang );
	}
}

function gg_seed_link_translations( $map ) {
	if ( function_exists( 'pll_save_post_translations' ) ) {
		pll_save_post_translations( $map );
	}
}

function gg_seed_home_content_th( $media = array() ) {
	$portrait = ! empty( $media['portrait'] ) ? wp_get_attachment_url( $media['portrait'] ) : '/wp-content/uploads/gg-seed/portrait-trang.jpeg';
	$hero     = ! empty( $media['hero'] ) ? wp_get_attachment_url( $media['hero'] ) : '/wp-content/uploads/gg-seed/hero-notebook.jpeg';
	$sg       = ! empty( $media['svc_game'] ) ? wp_get_attachment_url( $media['svc_game'] ) : '/wp-content/uploads/gg-seed/service-gamification.jpeg';
	$ss       = ! empty( $media['svc_strategy'] ) ? wp_get_attachment_url( $media['svc_strategy'] ) : '/wp-content/uploads/gg-seed/service-strategy.jpeg';
	$pid = (int) ( $media['portrait'] ?? 0 );
	$hid = (int) ( $media['hero'] ?? 0 );
	$gid = (int) ( $media['svc_game'] ?? 0 );
	$sid = (int) ( $media['svc_strategy'] ?? 0 );
	return '<!-- wp:cover {"url":"' . esc_url( $hero ) . '","id":' . $hid . ',"dimRatio":55,"minHeight":300,"align":"full"} -->
<div class="wp-block-cover alignfull" style="min-height:300px"><span aria-hidden="true" class="wp-block-cover__background has-background-dim" style="background-color:#132042"></span><img class="wp-block-cover__image-background" alt="" src="' . esc_url( $hero ) . '" data-object-fit="cover"/><div class="wp-block-cover__inner-container"><!-- wp:paragraph {"align":"center","style":{"color":{"text":"#8FD0EA"},"typography":{"fontSize":"14px","textTransform":"uppercase","letterSpacing":"0.12em","fontWeight":"600"}}} -->
<p class="has-text-align-center has-text-color" style="color:#8FD0EA;font-size:14px;font-weight:600;letter-spacing:0.12em;text-transform:uppercase">MOVE WITH MOTIVATION</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"textAlign":"center","level":1,"style":{"color":{"text":"#ffffff"}}} -->
<h1 class="wp-block-heading has-text-align-center has-text-color" style="color:#ffffff">เกมมิฟิเคชัน &amp; การวางแผนกลยุทธ์</h1>
<!-- /wp:heading --></div></div>
<!-- /wp:cover -->
<!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column {"width":"33%"} -->
<div class="wp-block-column" style="flex-basis:33%"><!-- wp:image {"id":' . $pid . ',"className":"is-style-rounded"} -->
<figure class="wp-block-image is-style-rounded"><img src="' . esc_url( $portrait ) . '" alt="ตรัง สุวรรณศิลป์"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->
<!-- wp:column {"width":"66%"} -->
<div class="wp-block-column" style="flex-basis:66%"><!-- wp:paragraph -->
<p><em>เกมมิฟิเคชันกับการวางแผนกลยุทธ์ คือสองเรื่องที่ผมหลงใหลที่สุดครับ</em></p>
<!-- /wp:paragraph -->
<!-- wp:paragraph -->
<p><em>ตอนแรกอาจดูไม่เกี่ยวกัน แต่พอใช้จริง ทั้งสองอย่างเสริมกันได้ดี</em></p>
<!-- /wp:paragraph -->
<!-- wp:paragraph -->
<p><em>การวางแผนกลยุทธ์ช่วยตั้งทิศทางและเป้าหมาย ส่วนเกมมิฟิเคชันช่วยให้คนอยากไปถึงเป้าหมายนั้นอย่างสนุก</em></p>
<!-- /wp:paragraph -->
<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"style":{"color":{"background":"#DDD94A","text":"#132042"}}} -->
<div class="wp-block-button"><a class="wp-block-button__link has-background has-text-color" href="/articles/" style="background-color:#DDD94A;color:#132042">อ่านบทความ →</a></div>
<!-- /wp:button -->
<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link" href="/contact/">ติดต่อ</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->
<!-- wp:heading -->
<h2 class="wp-block-heading">บริการ</h2>
<!-- /wp:heading -->
<!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:image {"id":' . $gid . '} -->
<figure class="wp-block-image"><img src="' . esc_url( $sg ) . '" alt=""/></figure>
<!-- /wp:image -->
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">เกมมิฟิเคชัน</h3>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>ออกแบบอบรมและเวิร์กช็อปเกมมิฟิเคชัน ให้เหมาะกับบุคคล สตาร์ทอัพ และองค์กร</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph -->
<p>และให้คำปรึกษาองค์กรที่อยากใช้เกมมิฟิเคชัน ทั้งเรื่องบริหารผลงานและบริหารทรัพยากรบุคคล</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->
<!-- wp:column -->
<div class="wp-block-column"><!-- wp:image {"id":' . $sid . '} -->
<figure class="wp-block-image"><img src="' . esc_url( $ss ) . '" alt=""/></figure>
<!-- /wp:image -->
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">การวางแผนกลยุทธ์</h3>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>ที่ปรึกษาการวางแผนกลยุทธ์ให้ธุรกิจ โดยเน้น SME</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph -->
<p>เป้าหมายของผมคือฝึกให้องค์กรวางแผนกลยุทธ์เองได้ เพื่อไม่ต้องพึ่งที่ปรึกษาไปตลอด</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->
<!-- wp:heading -->
<h2 class="wp-block-heading">บทความล่าสุด</h2>
<!-- /wp:heading -->
<!-- wp:latest-posts {"postsToShow":3,"displayPostContent":true,"excerptLength":24,"displayFeaturedImage":true,"displayPostDate":true} /-->
<!-- wp:heading {"anchor":"contact"} -->
<h2 class="wp-block-heading" id="contact">ติดต่อ</h2>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>อยากรู้ว่าเกมมิฟิเคชันกับการวางแผนกลยุทธ์จะช่วยให้ไปถึงเป้าหมายได้อย่างไร ทักมาคุยกันได้ครับ</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph -->
<p>ช่องทาง: <a href="https://web.facebook.com/GrowthGameIdea">Facebook</a> · <a href="https://www.youtube.com/channel/UCsEg65aHlNVERAZ1H2_Cj2A/featured">YouTube</a> · <a href="https://www.goodreads.com/author/show/21656276._">Goodreads</a> · <a href="https://www.blockdit.com/pages/600d1f1c393e750cdef0bc86">Blockdit</a></p>
<!-- /wp:paragraph -->
<!-- wp:paragraph -->
<p><a href="/contact/">ไปหน้าติดต่อ →</a></p>
<!-- /wp:paragraph -->';
}

function gg_seed_home_content_en( $media = array() ) {
	$portrait = ! empty( $media['portrait'] ) ? wp_get_attachment_url( $media['portrait'] ) : '/wp-content/uploads/gg-seed/portrait-trang.jpeg';
	$hero     = ! empty( $media['hero'] ) ? wp_get_attachment_url( $media['hero'] ) : '/wp-content/uploads/gg-seed/hero-notebook.jpeg';
	$sg       = ! empty( $media['svc_game'] ) ? wp_get_attachment_url( $media['svc_game'] ) : '/wp-content/uploads/gg-seed/service-gamification.jpeg';
	$ss       = ! empty( $media['svc_strategy'] ) ? wp_get_attachment_url( $media['svc_strategy'] ) : '/wp-content/uploads/gg-seed/service-strategy.jpeg';
	$pid = (int) ( $media['portrait'] ?? 0 );
	$hid = (int) ( $media['hero'] ?? 0 );
	$gid = (int) ( $media['svc_game'] ?? 0 );
	$sid = (int) ( $media['svc_strategy'] ?? 0 );
	return '<!-- wp:cover {"url":"' . esc_url( $hero ) . '","id":' . $hid . ',"dimRatio":55,"minHeight":300,"align":"full"} -->
<div class="wp-block-cover alignfull" style="min-height:300px"><span aria-hidden="true" class="wp-block-cover__background has-background-dim" style="background-color:#132042"></span><img class="wp-block-cover__image-background" alt="" src="' . esc_url( $hero ) . '" data-object-fit="cover"/><div class="wp-block-cover__inner-container"><!-- wp:paragraph {"align":"center","style":{"color":{"text":"#8FD0EA"},"typography":{"fontSize":"14px","textTransform":"uppercase","letterSpacing":"0.12em","fontWeight":"600"}}} -->
<p class="has-text-align-center has-text-color" style="color:#8FD0EA;font-size:14px;font-weight:600;letter-spacing:0.12em;text-transform:uppercase">MOVE WITH MOTIVATION</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"textAlign":"center","level":1,"style":{"color":{"text":"#ffffff"}}} -->
<h1 class="wp-block-heading has-text-align-center has-text-color" style="color:#ffffff">Gamification &amp; Strategic Planning</h1>
<!-- /wp:heading --></div></div>
<!-- /wp:cover -->
<!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column {"width":"33%"} -->
<div class="wp-block-column" style="flex-basis:33%"><!-- wp:image {"id":' . $pid . ',"className":"is-style-rounded"} -->
<figure class="wp-block-image is-style-rounded"><img src="' . esc_url( $portrait ) . '" alt="Trang Suwannasilp"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->
<!-- wp:column {"width":"66%"} -->
<div class="wp-block-column" style="flex-basis:66%"><!-- wp:paragraph -->
<p><em>Gamification and strategic planning are the two things I care about most.</em></p>
<!-- /wp:paragraph -->
<!-- wp:paragraph -->
<p><em>They can look unrelated at first. In practice, they work well together.</em></p>
<!-- /wp:paragraph -->
<!-- wp:paragraph -->
<p><em>Strategic planning sets the direction and the goal. Gamification helps people move toward that goal in a way that feels fun.</em></p>
<!-- /wp:paragraph -->
<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"style":{"color":{"background":"#DDD94A","text":"#132042"}}} -->
<div class="wp-block-button"><a class="wp-block-button__link has-background has-text-color" href="/articles-en/" style="background-color:#DDD94A;color:#132042">Read articles →</a></div>
<!-- /wp:button -->
<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link" href="/contact-en/">Get in Touch</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->
<!-- wp:heading -->
<h2 class="wp-block-heading">Services</h2>
<!-- /wp:heading -->
<!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:image {"id":' . $gid . '} -->
<figure class="wp-block-image"><img src="' . esc_url( $sg ) . '" alt=""/></figure>
<!-- /wp:image -->
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Gamification</h3>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>I design Gamification workshops for individuals, startups, and companies — shaped around what each one needs.</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph -->
<p>I also consult with companies that want to use Gamification for performance management or human resource management.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->
<!-- wp:column -->
<div class="wp-block-column"><!-- wp:image {"id":' . $sid . '} -->
<figure class="wp-block-image"><img src="' . esc_url( $ss ) . '" alt=""/></figure>
<!-- /wp:image -->
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Strategic Planning</h3>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Strategic planning consulting for businesses, with a focus on SMEs.</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph -->
<p>My goal is to help companies build their own strategic planning process, so they don’t have to rely on a consultant forever.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->
<!-- wp:heading -->
<h2 class="wp-block-heading">Latest articles</h2>
<!-- /wp:heading -->
<!-- wp:latest-posts {"postsToShow":3,"displayPostContent":true,"excerptLength":24,"displayFeaturedImage":true,"displayPostDate":true} /-->
<!-- wp:heading {"anchor":"contact"} -->
<h2 class="wp-block-heading" id="contact">Get in Touch</h2>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Want to see how gamification and strategic planning can help you reach your goals? Get in touch.</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph -->
<p>Channels: <a href="https://web.facebook.com/GrowthGameIdea">Facebook</a> · <a href="https://www.youtube.com/channel/UCsEg65aHlNVERAZ1H2_Cj2A/featured">YouTube</a> · <a href="https://www.goodreads.com/author/show/21656276._">Goodreads</a> · <a href="https://www.blockdit.com/pages/600d1f1c393e750cdef0bc86">Blockdit</a></p>
<!-- /wp:paragraph -->
<!-- wp:paragraph -->
<p><a href="/contact-en/">Contact page →</a></p>
<!-- /wp:paragraph -->';
}

function gg_seed_about_th() {
	return '<!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:image -->
<figure class="wp-block-image"><img src="/wp-content/uploads/gg-seed/portrait-trang.jpeg" alt="ตรัง สุวรรณศิลป์"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->
<!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph -->
<p>ผมชื่อตรัง สุวรรณศิลป์ จบปริญญาตรีวิศวกรรมเครื่องกลจากจุฬาลงกรณ์มหาวิทยาลัย ปี 2002</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph -->
<p>ผมทำงานเกือบสิบปีในฐานะวิศวกรบริการหลุมเจาะที่ ปตท. สำรวจและผลิตปิโตรเลียม (PTTEP)</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph -->
<p>ปี 2016 ผมเริ่มทำงานเป็นนักวางแผนกลยุทธ์อาวุโสที่ PTTEP และปี 2021 เป็นหัวหน้าทีมวางแผนกลยุทธ์ของ AI &amp; Robotics Ventures (ARV)</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph -->
<p>นอกจากงานกลยุทธ์ ผมหลงใหลเกมมิฟิเคชัน และเป็นผู้เขียนหนังสือ “เกมมิฟิเคชัน จูงใจคนด้วยกลไกเกม” จัดพิมพ์โดย SALT Publishing</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph -->
<p>ผมยังเป็นนักออกแบบบอร์ดเกม และเป็นแชมป์ Catan คนแรกของประเทศไทย</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->';
}

function gg_seed_about_en() {
	return '<!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:image -->
<figure class="wp-block-image"><img src="/wp-content/uploads/gg-seed/portrait-trang.jpeg" alt="Trang Suwannasilp"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->
<!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph -->
<p>I’m Trang Suwannasilp. I graduated from Chulalongkorn University in 2002 with a bachelor’s degree in mechanical engineering.</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph -->
<p>I spent nearly a decade as a well services engineer at PTT Exploration and Production (PTTEP).</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph -->
<p>In 2016, I began working as a senior strategic planner at PTTEP. In 2021, I became the head of the strategic planning team for AI &amp; Robotics Ventures (ARV).</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph -->
<p>Beyond strategy work, I care deeply about gamification. I’m the author of <em>Gamification: Motivating People with Game Mechanics</em> (“เกมมิฟิเคชัน จูงใจคนด้วยกลไกเกม”), published by SALT Publishing.</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph -->
<p>I’m also a board game designer, and Thailand’s first Catan champion.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->';
}

function gg_seed_contact_th() {
	return '<!-- wp:heading --><h2>ติดต่อ</h2><!-- /wp:heading -->
<!-- wp:paragraph --><p>อยากรู้ว่าเกมมิฟิเคชันกับการวางแผนกลยุทธ์จะช่วยให้ไปถึงเป้าหมายได้อย่างไร ทักมาคุยกันได้ครับ</p><!-- /wp:paragraph -->
<!-- wp:paragraph --><p>ผมยินดีรับฟังทั้งคำถามและฟีดแบ็กครับ ถ้ามีเรื่องเกมมิฟิเคชันหรือการวางแผนกลยุทธ์ที่อยากคุย ทักมาได้เลย</p><!-- /wp:paragraph -->
<!-- wp:paragraph --><p>ส่งข้อความถึงผมได้จากช่องทางด้านล่างครับ</p><!-- /wp:paragraph -->
<!-- wp:paragraph --><p>ช่องทาง: <a href="https://web.facebook.com/GrowthGameIdea">Facebook</a> · <a href="https://www.youtube.com/channel/UCsEg65aHlNVERAZ1H2_Cj2A/featured">YouTube</a> · <a href="https://www.goodreads.com/author/show/21656276._">Goodreads</a> · <a href="https://www.blockdit.com/pages/600d1f1c393e750cdef0bc86">Blockdit</a></p><!-- /wp:paragraph -->
<!-- wp:paragraph --><p>อีเมล: <a href="mailto:hello@growthgame.co">hello@growthgame.co</a> · Growth Game Co., Ltd. · ปากเกร็ด นนทบุรี</p><!-- /wp:paragraph -->';
}

function gg_seed_contact_en() {
	return '<!-- wp:heading --><h2>Get in Touch</h2><!-- /wp:heading -->
<!-- wp:paragraph --><p>Want to see how gamification and strategic planning can help you reach your goals?</p><!-- /wp:paragraph -->
<!-- wp:paragraph --><p>I’m here and happy to listen. Have a question about gamification or strategic planning? Send it over.</p><!-- /wp:paragraph -->
<!-- wp:paragraph --><p>Channels: <a href="https://web.facebook.com/GrowthGameIdea">Facebook</a> · <a href="https://www.youtube.com/channel/UCsEg65aHlNVERAZ1H2_Cj2A/featured">YouTube</a> · <a href="https://www.goodreads.com/author/show/21656276._">Goodreads</a> · <a href="https://www.blockdit.com/pages/600d1f1c393e750cdef0bc86">Blockdit</a></p><!-- /wp:paragraph -->
<!-- wp:paragraph --><p>Email: <a href="mailto:hello@growthgame.co">hello@growthgame.co</a> · Growth Game Co., Ltd. · Pak Kret, Nonthaburi</p><!-- /wp:paragraph -->';
}

function gg_seed_articles_dir() {
	$cands = array(
		WP_CONTENT_DIR . '/uploads/gg-seed/articles',
		WP_PLUGIN_DIR . '/gg-seed/articles',
		'/wordpress/wp-content/uploads/gg-seed/articles',
		'/wordpress/wp-content/plugins/gg-seed/articles',
	);
	foreach ( $cands as $d ) {
		if ( is_dir( $d ) && file_exists( $d . '/manifest.json' ) ) {
			return $d;
		}
	}
	return '';
}

function gg_seed_import_articles( $media_base = array() ) {
	$dir = gg_seed_articles_dir();
	if ( ! $dir ) {
		return array();
	}
	$manifest = json_decode( file_get_contents( $dir . '/manifest.json' ), true );
	if ( ! is_array( $manifest ) ) {
		return array();
	}
	require_once ABSPATH . 'wp-admin/includes/image.php';
	$ids = array();
	foreach ( $manifest as $item ) {
		$slug = sanitize_title( 'live-' . $item['safe'] );
		$existing = get_page_by_path( $slug, OBJECT, 'post' );
		$html = '';
		$html_path = $dir . '/' . $item['html_file'];
		if ( file_exists( $html_path ) ) {
			$html = file_get_contents( $html_path );
			$html = preg_replace( '#<script[^>]*>.*?</script>#is', '', $html );
		}
		$attach_id = 0;
		if ( ! empty( $item['image'] ) ) {
			$img_path = $dir . '/' . $item['image'];
			if ( file_exists( $img_path ) ) {
				$ft = wp_check_filetype( basename( $img_path ), null );
				$attach_id = wp_insert_attachment(
					array(
						'post_mime_type' => $ft['type'],
						'post_title'     => sanitize_file_name( $item['image'] ),
						'post_content'   => '',
						'post_status'    => 'inherit',
					),
					$img_path
				);
				if ( ! is_wp_error( $attach_id ) ) {
					$meta = wp_generate_attachment_metadata( $attach_id, $img_path );
					wp_update_attachment_metadata( $attach_id, $meta );
				} else {
					$attach_id = 0;
				}
			}
		}
		$postarr = array(
			'post_title'   => $item['title'],
			'post_name'    => $slug,
			'post_content' => $html,
			'post_excerpt' => isset( $item['excerpt'] ) ? wp_strip_all_tags( $item['excerpt'] ) : '',
			'post_status'  => 'publish',
			'post_type'    => 'post',
			'post_date'    => $item['date'] . ' 10:00:00',
		);
		if ( $existing ) {
			$postarr['ID'] = $existing->ID;
			$pid = wp_update_post( $postarr );
		} else {
			$pid = wp_insert_post( $postarr );
		}
		if ( is_wp_error( $pid ) || ! $pid ) {
			continue;
		}
		if ( $attach_id ) {
			set_post_thumbnail( $pid, $attach_id );
		}
		if ( ! empty( $item['categories'] ) ) {
			foreach ( $item['categories'] as $cname ) {
				$term = term_exists( $cname, 'category' );
				if ( ! $term ) {
					$term = wp_insert_term( $cname, 'category' );
				}
				if ( ! is_wp_error( $term ) ) {
					$tid = is_array( $term ) ? (int) $term['term_id'] : (int) $term;
					wp_set_post_categories( $pid, array( $tid ), true );
				}
			}
		}
		gg_seed_set_lang( $pid, 'th' );
		$ids[] = $pid;
	}
	return $ids;
}


function gg_seed_coming_soon_th() {
	return '<!-- wp:html -->
<div class="gg-soon" data-soon-lang="th">
  <button type="button" class="gg-soon-mush" id="gg-soon-mush" aria-label="จิ้มเห็ดดูสิ"><img src="/wp-content/uploads/gg-seed/mushroom.png" alt="เห็ด Growth Game"/><span class="gg-sweat">💦</span><span class="gg-sweat s2">💦</span></button>
  <p class="gg-soon-quest">QUEST LOCKED</p>
  <h2>เห็ดกำลังเก็บเลเวลอยู่ เดี๋ยวมา <em>(ร่าง)</em></h2>
  <p class="gg-soon-line" id="gg-soon-line">เห็ดขอแอบเก็บเลเวลแป๊บ อย่าเพิ่งเร่งนะ เดี๋ยวโกรธ <em>(ร่าง)</em></p>
  <div class="gg-soon-xp" id="gg-soon-xp"><div class="bar"><i></i></div><div class="meta"><b id="gg-soon-pct">99%</b><small>LEVEL UP · ค้างนานผิดปกติ</small></div></div>
  <p class="gg-soon-note">ยังไม่มีวันเปิดจริงในหน้านี้ — พอพร้อมจะอัปเดตให้เอง ไม่จกตา</p>
  <p class="gg-soon-actions"><a class="gg-btn-accent" href="/">กลับหน้าแรก</a> <a class="gg-btn-ghost" href="/articles/">ไปอ่านบทความก่อน</a></p>
  <form onsubmit="event.preventDefault();alert(\'รับเรื่องแล้ว (ม็อก)\');" class="gg-soon-form"><input type="email" required placeholder="อีเมลไว้ตอนเห็ดเลเวลครบ (เดโม)"/><button type="submit">บอกเห็ดทีเมื่อพร้อม</button><small>กล่องแจ้งเตือนเป็นเดโม — ยังไม่เก็บอีเมลจริง</small></form>
  <p class="gg-soon-tip">ทิป: จิ้มเห็ดได้ · มันจะหงุดหงิดนิด ๆ <em>(ร่าง)</em></p>
</div>

<!-- /wp:html -->';
}

function gg_seed_coming_soon_en() {
	return '<!-- wp:html -->
<div class="gg-soon" data-soon-lang="en">
  <button type="button" class="gg-soon-mush" id="gg-soon-mush" aria-label="Poke the mushroom"><img src="/wp-content/uploads/gg-seed/mushroom.png" alt="Growth Game mushroom"/><span class="gg-sweat">💦</span><span class="gg-sweat s2">💦</span></button>
  <p class="gg-soon-quest">QUEST LOCKED</p>
  <h2>Mushroom is grinding XP — BRB <em>(draft)</em></h2>
  <p class="gg-soon-line" id="gg-soon-line">Loading 99%… that last 1% is the boss fight <em>(draft)</em></p>
  <div class="gg-soon-xp" id="gg-soon-xp"><div class="bar"><i></i></div><div class="meta"><b id="gg-soon-pct">99%</b><small>LEVEL UP · stuck on purpose</small></div></div>
  <p class="gg-soon-note">No launch date here on purpose — we’ll update when it’s real.</p>
  <p class="gg-soon-actions"><a class="gg-btn-accent" href="/home-gg-en/">Back to Home</a> <a class="gg-btn-ghost" href="/articles-en/">Read articles instead</a></p>
  <form onsubmit="event.preventDefault();alert(\'Noted (mock)\');" class="gg-soon-form"><input type="email" required placeholder="Email for when the mushroom hits 100% (demo)"/><button type="submit">Ping me when ready</button><small>Notify box is a demo — nothing is emailed for real</small></form>
  <p class="gg-soon-tip">Tip: poke the mushroom. It gets mildly offended. <em>(draft)</em></p>
</div>

<!-- /wp:html -->';
}

function gg_seed_bilingual_pages( $media ) {
	$ok_pll = gg_seed_polylang_languages();

	$home_th = gg_seed_page( 'หน้าแรก', 'home-gg', gg_seed_home_content_th( $media ) );
	$home_en = gg_seed_page( 'Home', 'home-gg-en', gg_seed_home_content_en( $media ) );
	gg_seed_set_lang( $home_th, 'th' );
	gg_seed_set_lang( $home_en, 'en' );
	gg_seed_link_translations( array( 'th' => $home_th, 'en' => $home_en ) );

	$about_th = gg_seed_page( 'เกี่ยวกับ', 'about', gg_seed_about_th() );
	$about_en = gg_seed_page( 'About', 'about-en', gg_seed_about_en() );
	gg_seed_set_lang( $about_th, 'th' );
	gg_seed_set_lang( $about_en, 'en' );
	gg_seed_link_translations( array( 'th' => $about_th, 'en' => $about_en ) );

	$contact_th = gg_seed_page( 'ติดต่อ', 'contact', gg_seed_contact_th() );
	$contact_en = gg_seed_page( 'Contact', 'contact-en', gg_seed_contact_en() );
	gg_seed_set_lang( $contact_th, 'th' );
	gg_seed_set_lang( $contact_en, 'en' );
	gg_seed_link_translations( array( 'th' => $contact_th, 'en' => $contact_en ) );

	$articles_th = gg_seed_page( 'บทความ', 'articles', '<!-- wp:heading --><h2>บทความ</h2><!-- /wp:heading --><!-- wp:paragraph --><p>บทความจากเว็บจริง growthgame.co</p><!-- /wp:paragraph --><!-- wp:latest-posts {"postsToShow":10,"displayPostContent":true,"excerptLength":28,"displayFeaturedImage":true,"displayPostDate":true} /-->' );
	$coming_th = gg_seed_page( 'กำลังเก็บเลเวล…', 'coming-soon', gg_seed_coming_soon_th() );
	$coming_en = gg_seed_page( 'Leveling up…', 'coming-soon-en', gg_seed_coming_soon_en() );
	gg_seed_set_lang( $coming_th, 'th' );
	gg_seed_set_lang( $coming_en, 'en' );
	gg_seed_link_translations( array( 'th' => $coming_th, 'en' => $coming_en ) );

	$articles_en = gg_seed_page( 'Articles', 'articles-en', '<!-- wp:heading --><h2>Articles</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Posts imported from growthgame.co (bodies as published).</p><!-- /wp:paragraph --><!-- wp:latest-posts {"postsToShow":10,"displayPostContent":true,"excerptLength":28,"displayFeaturedImage":true,"displayPostDate":true} /-->' );
	gg_seed_set_lang( $articles_th, 'th' );
	gg_seed_set_lang( $articles_en, 'en' );
	gg_seed_link_translations( array( 'th' => $articles_th, 'en' => $articles_en ) );

	update_option( 'show_on_front', 'page' );
	update_option( 'page_on_front', $home_th );
	update_option( 'page_for_posts', $articles_th );

	return compact( 'home_th', 'home_en', 'about_th', 'about_en', 'contact_th', 'contact_en', 'articles_th', 'articles_en', 'coming_th', 'coming_en', 'ok_pll' );
}

function gg_seed_bilingual_menus( $pages ) {
	$menu_name = 'Growth Game TH';
	$menu_id = wp_create_nav_menu( $menu_name );
	if ( is_wp_error( $menu_id ) ) {
		foreach ( wp_get_nav_menus() as $m ) {
			if ( $m->name === $menu_name ) {
				$menu_id = $m->term_id;
				break;
			}
		}
	}
	if ( $menu_id && ! is_wp_error( $menu_id ) ) {
		$old = wp_get_nav_menu_items( $menu_id );
		if ( $old ) {
			foreach ( $old as $oi ) { wp_delete_post( $oi->ID, true ); }
		}
	}
	$items = array(
		array( 'หน้าแรก', $pages['home_th'] ),
		array( 'เกี่ยวกับ', $pages['about_th'] ),
		array( 'บทความ', $pages['articles_th'] ),
		array( 'คอร์สออนไลน์', $pages['coming_th'] ),
		array( 'กิจกรรม', $pages['coming_th'] ),
		array( 'ติดต่อ', $pages['contact_th'] ),
	);
	foreach ( $items as $it ) {
		wp_update_nav_menu_item( $menu_id, 0, array(
			'menu-item-title'  => $it[0],
			'menu-item-object' => 'page',
			'menu-item-object-id' => $it[1],
			'menu-item-type'   => 'post_type',
			'menu-item-status' => 'publish',
		) );
	}
	$menu_en = wp_create_nav_menu( 'Growth Game EN' );
	if ( is_wp_error( $menu_en ) ) {
		foreach ( wp_get_nav_menus() as $m ) {
			if ( $m->name === 'Growth Game EN' ) {
				$menu_en = $m->term_id;
				break;
			}
		}
	}
	if ( $menu_en && ! is_wp_error( $menu_en ) ) {
		$old = wp_get_nav_menu_items( $menu_en );
		if ( $old ) {
			foreach ( $old as $oi ) { wp_delete_post( $oi->ID, true ); }
		}
	}
	$items_en = array(
		array( 'Home', $pages['home_en'] ),
		array( 'About', $pages['about_en'] ),
		array( 'Articles', $pages['articles_en'] ),
		array( 'Online Courses', $pages['coming_en'] ),
		array( 'Events', $pages['coming_en'] ),
		array( 'Contact', $pages['contact_en'] ),
	);
	foreach ( $items_en as $it ) {
		wp_update_nav_menu_item( $menu_en, 0, array(
			'menu-item-title'  => $it[0],
			'menu-item-object' => 'page',
			'menu-item-object-id' => $it[1],
			'menu-item-type'   => 'post_type',
			'menu-item-status' => 'publish',
		) );
	}
	if ( function_exists( 'pll_set_term_language' ) ) {
		pll_set_term_language( $menu_id, 'th' );
		pll_set_term_language( $menu_en, 'en' );
		if ( function_exists( 'pll_save_term_translations' ) ) {
			pll_save_term_translations( array( 'th' => $menu_id, 'en' => $menu_en ) );
		}
	}
	$locations = get_theme_mod( 'nav_menu_locations' );
	if ( ! is_array( $locations ) ) {
		$locations = array();
	}
	$locations['primary'] = $menu_id;
	set_theme_mod( 'nav_menu_locations', $locations );

	// Block theme header uses a wp_navigation post — replace with focus menu.
	$nav_content = '';
	foreach ( $items as $it ) {
		$url = get_permalink( $it[1] );
		$nav_content .= '<!-- wp:navigation-link {"label":"' . esc_attr( $it[0] ) . '","type":"page","id":' . (int) $it[1] . ',"url":"' . esc_url( $url ) . '","kind":"post-type"} /-->';
	}
	$existing_nav = get_posts( array(
		'post_type'      => 'wp_navigation',
		'title'          => 'Growth Game Main',
		'posts_per_page' => 1,
		'post_status'    => 'any',
	) );
	if ( $existing_nav ) {
		wp_update_post( array(
			'ID'           => $existing_nav[0]->ID,
			'post_content' => $nav_content,
			'post_status'  => 'publish',
		) );
	} else {
		wp_insert_post( array(
			'post_title'   => 'Growth Game Main',
			'post_status'  => 'publish',
			'post_type'    => 'wp_navigation',
			'post_content' => $nav_content,
		) );
	}

	// Point old courses/events pages at coming-soon content so leftover links land correctly.
	if ( ! empty( $pages['coming_th'] ) ) {
		$soon = get_post( $pages['coming_th'] );
		if ( $soon ) {
			foreach ( array( 'courses', 'events' ) as $slug ) {
				$p = get_page_by_path( $slug );
				if ( $p ) {
					wp_update_post( array(
						'ID'           => $p->ID,
						'post_content' => $soon->post_content,
						'post_title'   => $slug === 'courses' ? 'คอร์สออนไลน์' : 'กิจกรรม',
					) );
				}
			}
		}
	}
}
