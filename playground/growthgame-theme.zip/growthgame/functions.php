<?php
add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style( 'growthgame-fonts', 'https://fonts.googleapis.com/css2?family=Kanit:wght@400;500;600&family=Poppins:wght@400;500;600&display=swap', array(), null );
	wp_enqueue_style( 'growthgame-child', get_stylesheet_uri(), array( 'growthgame-fonts' ), '1.2.8' );
	$css  = ':root{--gg-deep:#132042;--gg-light:#8FD0EA;--gg-gray:#ECECEE;--gg-lilac:#5D68D8;--gg-violet:#343273;--gg-yellow:#DDD94A;}';
	$css .= 'body{font-family:Kanit,Poppins,system-ui,sans-serif;}a{color:var(--gg-lilac)}.wp-site-blocks{font-family:Kanit,Poppins,system-ui,sans-serif}';
	$css .= '.gg-banner{background:#DDD94A;color:#132042;text-align:center;padding:8px 12px;font-size:14px;font-weight:500}';
	$css .= 'body.home .wp-block-post-title,body.home .entry-title,body.home h1.wp-block-post-title{display:none!important;}';
	$css .= '.gg-lang{display:inline-flex;border:1px solid #d9d9e0;border-radius:999px;overflow:hidden;margin:8px 12px;vertical-align:middle}';
	$css .= '.gg-lang a{padding:6px 12px;font-size:13px;font-weight:600;text-decoration:none;color:#4a5270;background:#fff}';
	$css .= '.gg-lang a.active{background:#132042;color:#fff}';
	$css .= '.gg-lang a+a{border-left:1px solid #d9d9e0}';
	/* Preview mode: hide cart / account / services / portfolio / shop / app chrome */
	$css .= '.wp-block-navigation-item a[href*="สมัคร"],.wp-block-navigation-item a[href*="my-account"],.wp-block-navigation-item a[href*="portfolio"],.wp-block-navigation-item a[href*="services"],.wp-block-navigation-item a[href*="/app"],a[href*="สมัครคอร์ส"],.wp-block-button a[href*="/courses/"] .wc-block{display:none!important;}';
	$css .= 'footer .wp-block-navigation-item a[href*="/blog"],footer .wp-block-navigation-item a[href*="faq"],footer .wp-block-navigation-item a[href*="author"],footer .wp-block-navigation-item a[href*="pattern"],footer .wp-block-navigation-item a[href*="theme"],footer .wp-block-navigation-item a[href*="events"]:not([href*="coming-soon"]){display:none!important;}';
		/* Coming-soon playful */
	$css .= '.gg-soon{max-width:520px;margin:0 auto;padding:36px 24px;text-align:center;color:#fff;background:linear-gradient(165deg,#132042,#343273 55%,#1a2450);border-radius:24px;border:1px solid rgba(143,208,234,.35)}';
	$css .= '.gg-soon-quest{color:#8FD0EA;letter-spacing:.08em;font-weight:600;text-transform:uppercase}';
	$css .= '.gg-soon h2{color:#fff;font-size:26px;line-height:1.35;margin:8px 0 10px}';
	$css .= '.gg-soon-line{color:#ECECEE;min-height:3.2em}';
	$css .= '.gg-soon-mush{position:relative;width:120px;height:120px;margin:0 auto 16px;border:0;background:transparent;cursor:pointer;animation:gg-mush-bob 2.2s ease-in-out infinite}';
	$css .= '.gg-soon-mush img{width:100%;height:auto;filter:drop-shadow(0 8px 18px rgba(0,0,0,.35));display:block}';
	$css .= '.gg-soon-mush.squish img{animation:gg-mush-squish .45s ease}';
	$css .= '.gg-sweat{position:absolute;top:8px;right:2px;animation:gg-sweat 1.6s ease-in-out infinite}';
	$css .= '.gg-sweat.s2{left:6px;right:auto;top:18px;font-size:14px;animation-delay:.55s}';
	$css .= '@keyframes gg-mush-bob{0%,100%{transform:translateY(0) rotate(-3deg)}50%{transform:translateY(-10px) rotate(3deg)}}';
	$css .= '@keyframes gg-mush-squish{0%{transform:scale(1)}35%{transform:scale(1.18,.72)}70%{transform:scale(.88,1.14)}100%{transform:scale(1)}}';
	$css .= '@keyframes gg-sweat{0%,100%{transform:translateY(0);opacity:.35}50%{transform:translateY(10px);opacity:1}}';
	$css .= '.gg-soon-xp{margin:18px auto 8px;max-width:280px;text-align:left}';
	$css .= '.gg-soon-xp .bar{height:14px;background:rgba(255,255,255,.15);border-radius:999px;overflow:hidden;border:1px solid rgba(143,208,234,.4)}';
	$css .= '.gg-soon-xp .bar i{display:block;height:100%;width:99%;background:linear-gradient(90deg,#5D68D8,#8FD0EA,#DDD94A);background-size:200% 100%;animation:gg-xp-shine 2s linear infinite;border-radius:999px}';
	$css .= '.gg-soon-xp.jiggle .bar{animation:gg-xp-jiggle .55s ease}';
	$css .= '@keyframes gg-xp-shine{0%{background-position:0% 50%}100%{background-position:200% 50%}}';
	$css .= '@keyframes gg-xp-jiggle{0%,100%{transform:translateX(0)}25%{transform:translateX(-4px)}50%{transform:translateX(5px)}75%{transform:translateX(-2px)}}';
	$css .= '.gg-soon-xp .meta{display:flex;justify-content:space-between;margin-top:6px;align-items:baseline}';
	$css .= '.gg-soon-xp .meta b{color:#DDD94A;font-size:18px}';
	$css .= '.gg-soon-xp .meta small{color:#8FD0EA;font-size:12px}';
	$css .= '.gg-soon-note,.gg-soon-tip{color:#aab0c6;font-size:13px}';
	$css .= '.gg-soon-actions{display:flex;flex-wrap:wrap;gap:10px;justify-content:center;margin:18px 0}';
	$css .= '.gg-btn-accent{display:inline-block;padding:10px 16px;border-radius:999px;background:#DDD94A;color:#132042!important;font-weight:600;text-decoration:none}';
	$css .= '.gg-btn-ghost{display:inline-block;padding:10px 16px;border-radius:999px;border:1px solid #8FD0EA;color:#8FD0EA!important;text-decoration:none}';
	$css .= '.gg-soon-form{max-width:360px;margin:12px auto 0;display:grid;gap:8px}';
	$css .= '.gg-soon-form input{padding:12px 14px;border-radius:999px;border:1px solid #5D68D8;background:#1a2450;color:#fff}';
	$css .= '.gg-soon-form button{padding:11px 18px;border-radius:999px;border:0;background:#5D68D8;color:#fff;font-weight:600;cursor:pointer}';
	$css .= '.gg-soon-form small{color:#aab0c6;font-size:12px}';
	$css .= '.gg-achieve{position:fixed;left:50%;bottom:28px;transform:translateX(-50%) translateY(20px);background:linear-gradient(135deg,#5D68D8,#343273);color:#fff;border:1px solid rgba(221,217,74,.55);border-radius:16px;padding:12px 16px;z-index:9999;opacity:0;transition:.25s;min-width:260px;max-width:90vw}';
	$css .= '.gg-achieve.show{opacity:1;transform:translateX(-50%) translateY(0)}';
	$css .= '.gg-achieve .tag{display:block;font-size:11px;letter-spacing:.08em;color:#DDD94A;font-weight:600}';
	wp_add_inline_style( 'growthgame-child', $css );
} );

add_action( 'wp_body_open', function () {
	echo '<div class="gg-banner">พรีวิวหน้าเดิมของ growthgame.co (ยังไม่ใช่เว็บจริง)</div>';
	$th_url = home_url( '/' );
	$en_url = home_url( '/home-gg-en/' );
	$cur = 'th';
	if ( function_exists( 'pll_the_languages' ) ) {
		$langs = pll_the_languages( array( 'raw' => 1, 'hide_if_empty' => 0 ) );
		if ( is_array( $langs ) && $langs ) {
			echo '<div style="text-align:right;padding:6px 16px;background:#fff;border-bottom:1px solid #ececee"><nav class="gg-lang" aria-label="Language">';
			foreach ( $langs as $l ) {
				$cls = ! empty( $l['current_lang'] ) ? ' class="active"' : '';
				echo '<a href="' . esc_url( $l['url'] ) . '"' . $cls . '>' . esc_html( strtoupper( $l['slug'] ) ) . '</a>';
			}
			echo '</nav></div>';
			return;
		}
	}
	if ( is_page() ) {
		$slug = get_post_field( 'post_name', get_queried_object_id() );
		$pairs = array(
			'home-gg' => 'home-gg-en', 'home-gg-en' => 'home-gg',
			'about' => 'about-en', 'about-en' => 'about',
			'contact' => 'contact-en', 'contact-en' => 'contact',
			'articles' => 'articles-en', 'articles-en' => 'articles',
			'coming-soon' => 'coming-soon-en', 'coming-soon-en' => 'coming-soon',
			'courses' => 'coming-soon-en', 'events' => 'coming-soon-en',
		);
		if ( isset( $pairs[ $slug ] ) ) {
			$sib = get_page_by_path( $pairs[ $slug ] );
			$self = get_queried_object_id();
			if ( in_array( $slug, array( 'home-gg-en', 'about-en', 'contact-en', 'articles-en', 'coming-soon-en' ), true ) ) {
				$cur = 'en';
				$en_url = get_permalink( $self );
				if ( $sib ) { $th_url = get_permalink( $sib ); }
			} else {
				$cur = 'th';
				$th_url = ( in_array( $slug, array( 'courses', 'events' ), true ) && ( $soon = get_page_by_path( 'coming-soon' ) ) )
					? get_permalink( $soon )
					: get_permalink( $self );
				if ( $sib ) { $en_url = get_permalink( $sib ); }
			}
		}
	}
	echo '<div style="text-align:right;padding:6px 16px;background:#fff;border-bottom:1px solid #ececee"><nav class="gg-lang" aria-label="Language">';
	echo '<a href="' . esc_url( $th_url ) . '"' . ( $cur === 'th' ? ' class="active"' : '' ) . '>TH</a>';
	echo '<a href="' . esc_url( $en_url ) . '"' . ( $cur === 'en' ? ' class="active"' : '' ) . '>EN</a>';
	echo '</nav></div>';
} );

add_filter( 'render_block', function ( $block_content, $block ) {
	if ( is_front_page() && isset( $block['blockName'] ) && 'core/post-title' === $block['blockName'] ) {
		return '';
	}
	return $block_content;
}, 10, 2 );

// Redirect leftover course/event URLs to coming-soon (TH/EN).
add_action( 'template_redirect', function () {
	if ( is_admin() ) {
		return;
	}
	$slug = '';
	if ( is_page() ) {
		$slug = get_post_field( 'post_name', get_queried_object_id() );
	}
	$path = trim( (string) parse_url( $_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH ), '/' );
	$hit = in_array( $slug, array( 'courses', 'events' ), true )
		|| preg_match( '#(^|/)(courses|events)(/|$)#', $path );
	if ( ! $hit ) {
		return;
	}
	$en = ( false !== strpos( $path, 'coming-soon-en' ) ) || is_page( 'coming-soon-en' );
	$target = get_page_by_path( $en ? 'coming-soon-en' : 'coming-soon' );
	if ( $target ) {
		wp_safe_redirect( get_permalink( $target ), 302 );
		exit;
	}
} );

// Soft-rewrite any remaining courses/events hrefs in HTML output.
add_action( 'template_redirect', function () {
	if ( is_admin() || wp_doing_ajax() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
		return;
	}
	ob_start( function ( $html ) {
		if ( ! is_string( $html ) || $html === '' ) {
			return $html;
		}
		$soon = home_url( '/coming-soon/' );
		$html = preg_replace( '#https?://[^"\']+/courses/?#', $soon, $html );
		$html = preg_replace( '#https?://[^"\']+/events/?#', $soon, $html );
		$html = preg_replace( '#(?<=href=["\'])/courses/?#', '/coming-soon/', $html );
		$html = preg_replace( '#(?<=href=["\'])/events/?#', '/coming-soon/', $html );
		// Relabel course nav item if still old wording.
		$html = str_replace( '>คอร์สเรียน</span>', '>คอร์สออนไลน์</span>', $html );
		$html = str_replace( '>Courses</span>', '>Online Courses</span>', $html );
		return $html;
	} );
}, 0 );



add_action( 'wp_footer', function () {
	if ( ! is_page( array( 'coming-soon', 'coming-soon-en', 'courses', 'events' ) ) ) {
		return;
	}
	$en = is_page( 'coming-soon-en' );
	$lines = $en
		? array(
			'Loading 99%… that last 1% is the boss fight',
			'Mushroom asked for just one more snack quest. Suspicious.',
			'Achievement unlocked: Curious Visitor — you arrived before the mushroom',
			'Please stand by. XP is buffering… emotionally.',
			'Don’t refresh — it might drop back to 98% out of spite',
			'Courses & events are AFK. Mushroom is optimizing vibes.',
		)
		: array(
			'เห็ดขอแอบเก็บเลเวลแป๊บ อย่าเพิ่งเร่งนะ เดี๋ยวโกรธ',
			'Loading 99%… อีก 1% นี่แหละยากสุด',
			'Achievement unlocked: คนขี้สงสัย — คุณมาเร็วกว่าเห็ด',
			'ระบบกำลังฟาร์ม XP… ค้างที่ 99% (สงสัยแอบทำเควสต์ของว่าง)',
			'อย่าเพิ่งรีเฟรช เดี๋ยวหลุดเซฟแล้วหล่นเหลือ 98%',
			'คอร์สกับกิจกรรมขอ AFK ก่อน เห็ดกำลังปรับบาลานซ์ความน่ารัก',
		);
	$poke = $en
		? array( 'Hey! Soft poke only. Cap is delicate.', 'Squish logged. XP still 99%. Rude.', 'Stop speedrunning my level-up!', 'That tickles. Still not 100% though.' )
		: array( 'เฮ้ย! จิ้มเบา ๆ หน่อย หมวกยังอ่อนอยู่', 'บันทึกการบีบแล้ว — XP ยัง 99% อยู่ดี', 'อย่าสปีดรันเลเวลของเห็ดสิ!', 'คันนะ… แต่ยังไม่ครบ 100% อยู่ดี' );
	$mark = $en ? ' <em>(draft)</em>' : ' <em>(ร่าง)</em>';
	$achieve = $en
		? array( 'Curious Visitor — you showed up before the mushroom finished grinding.', 'SECRET POKE', 'Mushroom respect +1. Courses still loading.' )
		: array( 'คนขี้สงสัย — คุณมาเร็วกว่าเห็ดที่ยังค้าง 99%', 'อีสเตอร์เอ้ก', 'เห็ดให้หัวใจ +1 · คอร์สยังโหลดอยู่ดี' );
	?>
<script id="gg-soon-js">
(function(){
  var mush=document.getElementById('gg-soon-mush');
  if(!mush) return;
  var lines=<?php echo wp_json_encode( $lines, JSON_UNESCAPED_UNICODE ); ?>;
  var poke=<?php echo wp_json_encode( $poke, JSON_UNESCAPED_UNICODE ); ?>;
  var mark=<?php echo wp_json_encode( $mark, JSON_UNESCAPED_UNICODE ); ?>;
  var achieve=<?php echo wp_json_encode( $achieve, JSON_UNESCAPED_UNICODE ); ?>;
  var line=document.getElementById('gg-soon-line');
  var xp=document.getElementById('gg-soon-xp');
  var pct=document.getElementById('gg-soon-pct');
  var i=0,n=0;
  function toast(tag,msg){
    var t=document.createElement('div'); t.className='gg-achieve show';
    t.innerHTML='<span class="tag">'+tag+'</span><span class="msg">'+msg+'</span>';
    document.body.appendChild(t); setTimeout(function(){t.classList.remove('show');},3200);
  }
  setInterval(function(){
    i=(i+1)%lines.length;
    if(line) line.innerHTML=lines[i]+mark;
    if(xp){xp.classList.remove('jiggle'); void xp.offsetWidth; xp.classList.add('jiggle');}
    if(pct) pct.textContent='99%';
  },4200);
  setTimeout(function(){ toast('ACHIEVEMENT UNLOCKED', achieve[0]); },700);
  mush.addEventListener('click',function(){
    n++; mush.classList.toggle('squish', !!(n%2));
    if(line) line.innerHTML=poke[n%poke.length]+mark;
    if(xp){xp.classList.remove('jiggle'); void xp.offsetWidth; xp.classList.add('jiggle');}
    if(n===3) toast(achieve[1], achieve[2]);
  });
})();
</script>
	<?php
}, 99 );
